-- =====================================================================
-- Sistema de Reservas de Espacios - Escuela Militar
-- Script DDL para PostgreSQL — versión 2
-- Una sola base de datos, un esquema por microservicio
-- MS-4 (Agente IA) no tiene esquema propio: no persiste datos
-- Decisión explícita: se usa SERIAL (entero autoincremental) como PK
--   en lugar de UUID, adecuado para una sola instancia de base de datos
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS ms2_verificacion;
CREATE SCHEMA IF NOT EXISTS ms1_nucleo;
CREATE SCHEMA IF NOT EXISTS ms3_inventario;
CREATE SCHEMA IF NOT EXISTS ms5_quejas;

-- =====================================================================
-- ESQUEMA: ms2_verificacion
-- Cuentas, roles, permisos, auditoría
-- =====================================================================

-- 4 tipos de cuenta fijos (no editables desde la app):
--   ADMINISTRADOR : único, permisos fijos, aprueba/rechaza reservas y gestiona mantenimiento
--   MODERADOR     : múltiples (uno por sección académica), permisos editables por rol,
--                   reserva en nombre de los cadetes de su sección
--   USUARIO       : cadetes, pueden reservar por cuenta propia en tiempo libre, permisos fijos
--   EXTERNO       : convenios con escuelas externas — estructura presente, lógica pausada
CREATE TABLE ms2_verificacion.tipo_cuenta (
    id      SERIAL PRIMARY KEY,
    nombre  VARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE ms1_nucleo.tipo_espacio (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(60) NOT NULL,
    tipo_padre_id   INTEGER REFERENCES ms1_nucleo.tipo_espacio(id)
);

-- ROL solo aplica a cuentas de tipo MODERADOR
CREATE TABLE ms2_verificacion.rol (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(60) NOT NULL,
    tipo_cuenta_id  INTEGER NOT NULL REFERENCES ms2_verificacion.tipo_cuenta(id),
    UNIQUE (nombre, tipo_cuenta_id)
);

CREATE TABLE ms2_verificacion.permiso (
    id          SERIAL PRIMARY KEY,
    codigo      VARCHAR(60)  NOT NULL UNIQUE,
    descripcion VARCHAR(200)
);

-- Tabla intermedia ROL <-> PERMISO (solo para MODERADOREs)
CREATE TABLE ms2_verificacion.rol_permiso (
    rol_id      INTEGER NOT NULL REFERENCES ms2_verificacion.rol(id)     ON DELETE CASCADE,
    permiso_id  INTEGER NOT NULL REFERENCES ms2_verificacion.permiso(id) ON DELETE CASCADE,
    PRIMARY KEY (rol_id, permiso_id)
);

-- Jerarquía de prioridad para resolución de conflictos de reserva:
--   ADMINISTRADOR = 3 | MODERADOR = 2 | USUARIO = 1 | EXTERNO = 0
CREATE TABLE ms2_verificacion.usuario (
    id                  SERIAL PRIMARY KEY,
    tipo_cuenta_id      INTEGER      NOT NULL REFERENCES ms2_verificacion.tipo_cuenta(id),
    rol_id              INTEGER               REFERENCES ms2_verificacion.rol(id),  -- solo MODERADOR
    nombre_usuario      VARCHAR(60)  NOT NULL UNIQUE,
    alias               VARCHAR(60),
    hash_password       VARCHAR(255) NOT NULL,
    prioridad           SMALLINT     NOT NULL DEFAULT 0,  -- 3/2/1/0 según tipo_cuenta
    intentos_fallidos   SMALLINT     NOT NULL DEFAULT 0,
    bloqueado           BOOLEAN      NOT NULL DEFAULT FALSE,
    fecha_creacion      TIMESTAMP    NOT NULL DEFAULT now(),
    creado_por          INTEGER               REFERENCES ms2_verificacion.usuario(id),
    bloqueada_en        TIMESTAMP,
    desbloqueada_por    INTEGER               REFERENCES ms2_verificacion.usuario(id)
);

-- Trigger: solo MODERADOREs pueden tener rol_id asignado
CREATE OR REPLACE FUNCTION ms2_verificacion.validar_rol_moderador()
RETURNS TRIGGER AS $$
DECLARE
    nombre_tipo VARCHAR(30);
BEGIN
    IF NEW.rol_id IS NOT NULL THEN
        SELECT nombre INTO nombre_tipo
        FROM ms2_verificacion.tipo_cuenta
        WHERE id = NEW.tipo_cuenta_id;

        IF nombre_tipo <> 'MODERADOR' THEN
            RAISE EXCEPTION 'rol_id solo puede asignarse a cuentas de tipo MODERADOR (tipo actual: %)', nombre_tipo;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_rol_moderador
BEFORE INSERT OR UPDATE ON ms2_verificacion.usuario
FOR EACH ROW EXECUTE FUNCTION ms2_verificacion.validar_rol_moderador();

-- Secciones académicas (antes USUARIO_AREA / SECCION):
-- asocia un moderador con los tipos de espacio que administra su sección
CREATE TABLE ms2_verificacion.seccion_academica (
    usuario_id      INTEGER NOT NULL REFERENCES ms2_verificacion.usuario(id)       ON DELETE CASCADE,
    tipo_espacio_id INTEGER NOT NULL REFERENCES ms1_nucleo.tipo_espacio(id)        ON DELETE CASCADE,
    PRIMARY KEY (usuario_id, tipo_espacio_id)
);

CREATE TABLE ms2_verificacion.registro_acceso (
    id          SERIAL PRIMARY KEY,
    usuario_id  INTEGER     NOT NULL REFERENCES ms2_verificacion.usuario(id),
    fecha       TIMESTAMP   NOT NULL DEFAULT now(),
    tipo_evento VARCHAR(30) NOT NULL,  -- LOGIN / LOGOUT / BLOQUEO / DESBLOQUEO
    exito       BOOLEAN     NOT NULL,
    ip          VARCHAR(45)
);

CREATE TABLE ms2_verificacion.sesion_activa (
    id                  SERIAL PRIMARY KEY,
    usuario_id          INTEGER      NOT NULL REFERENCES ms2_verificacion.usuario(id) ON DELETE CASCADE,
    token               VARCHAR(500) NOT NULL,
    fecha_creacion      TIMESTAMP    NOT NULL DEFAULT now(),
    fecha_expiracion    TIMESTAMP    NOT NULL,
    revocada            BOOLEAN      NOT NULL DEFAULT FALSE
);

-- =====================================================================
-- ESQUEMA: ms1_nucleo
-- Espacios, reservas, convenios, notificaciones
-- =====================================================================

CREATE TABLE ms1_nucleo.espacio (
    id                      SERIAL PRIMARY KEY,
    tipo_espacio_id         INTEGER     NOT NULL REFERENCES ms1_nucleo.tipo_espacio(id),
    nombre                  VARCHAR(80) NOT NULL,
    encargado_usuario_id    INTEGER              REFERENCES ms2_verificacion.usuario(id),
    capacidad_maxima        SMALLINT    NOT NULL DEFAULT 0,  -- máximo de personas permitidas
    activo                  BOOLEAN     NOT NULL DEFAULT TRUE
);

CREATE TABLE ms1_nucleo.convenio (
    id               SERIAL PRIMARY KEY,
    entidad_externa  VARCHAR(120) NOT NULL,
    tipo_convenio    VARCHAR(60),
    vigente_desde    DATE         NOT NULL,
    vigente_hasta    DATE,
    notas_operativas TEXT
    -- EXTERNO pausado: estructura presente, sin lógica activa aún
);

CREATE TABLE ms1_nucleo.convenio_espacio (
    convenio_id INTEGER NOT NULL REFERENCES ms1_nucleo.convenio(id) ON DELETE CASCADE,
    espacio_id  INTEGER NOT NULL REFERENCES ms1_nucleo.espacio(id)  ON DELETE CASCADE,
    PRIMARY KEY (convenio_id, espacio_id)
);

CREATE TABLE ms1_nucleo.bloque_convenio (
    id                        SERIAL PRIMARY KEY,
    convenio_id               INTEGER  NOT NULL,
    espacio_id                INTEGER  NOT NULL,
    dia_semana                SMALLINT NOT NULL CHECK (dia_semana BETWEEN 1 AND 7),
    hora_inicio               TIME     NOT NULL,
    hora_fin                  TIME     NOT NULL,
    modificable_por_defecto   BOOLEAN  NOT NULL DEFAULT FALSE,
    modificado_por_usuario_id INTEGER           REFERENCES ms2_verificacion.usuario(id),
    motivo_modificacion       VARCHAR(255),
    FOREIGN KEY (convenio_id, espacio_id)
        REFERENCES ms1_nucleo.convenio_espacio(convenio_id, espacio_id) ON DELETE CASCADE
);

-- Estados posibles de una reserva:
--   PENDIENTE             : recién creada, esperando resolución del admin
--   APROBADA              : aprobada por el admin
--   RECHAZADA             : rechazada por el admin (con motivo)
--   CANCELADA             : cancelada voluntariamente por el solicitante
--   CANCELADA_JERARQUIA   : cancelada automáticamente porque una reserva de mayor
--                           jerarquía fue aprobada para el mismo espacio y horario
CREATE TABLE ms1_nucleo.reserva (
    id                      SERIAL PRIMARY KEY,
    tipo_espacio_id         INTEGER      NOT NULL REFERENCES ms1_nucleo.tipo_espacio(id),  -- categoría solicitada
    espacio_preferido_id    INTEGER               REFERENCES ms1_nucleo.espacio(id),       -- instancia preferida (opcional)
    espacio_asignado_id     INTEGER               REFERENCES ms1_nucleo.espacio(id),       -- asignada al aprobar
    solicitante_usuario_id  INTEGER      NOT NULL REFERENCES ms2_verificacion.usuario(id),
    resolutor_usuario_id    INTEGER               REFERENCES ms2_verificacion.usuario(id), -- admin que aprueba/rechaza
    convenio_id             INTEGER               REFERENCES ms1_nucleo.convenio(id),
    estado                  VARCHAR(25)  NOT NULL DEFAULT 'PENDIENTE'
                            CHECK (estado IN ('PENDIENTE','APROBADA','RECHAZADA','CANCELADA','CANCELADA_JERARQUIA')),
    num_personas            SMALLINT     NOT NULL DEFAULT 1,
    orden_llegada           INTEGER,
    motivo_rechazo          VARCHAR(500),
    fecha_solicitud         TIMESTAMP    NOT NULL DEFAULT now(),
    fecha_inicio            TIMESTAMP    NOT NULL,
    fecha_fin               TIMESTAMP    NOT NULL
);

-- Trigger: al aprobar una reserva, cancela por jerarquía las que choquen
-- en mismo espacio y horario con menor prioridad de solicitante
CREATE OR REPLACE FUNCTION ms1_nucleo.cancelar_por_jerarquia()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.estado = 'APROBADA' AND OLD.estado <> 'APROBADA' THEN
        UPDATE ms1_nucleo.reserva r
        SET estado = 'CANCELADA_JERARQUIA'
        WHERE r.id <> NEW.id
          AND r.estado = 'APROBADA'
          AND r.espacio_asignado_id = NEW.espacio_asignado_id
          AND r.fecha_inicio < NEW.fecha_fin
          AND r.fecha_fin   > NEW.fecha_inicio
          AND (
              SELECT u.prioridad FROM ms2_verificacion.usuario u
              WHERE u.id = r.solicitante_usuario_id
          ) < (
              SELECT u.prioridad FROM ms2_verificacion.usuario u
              WHERE u.id = NEW.solicitante_usuario_id
          );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_cancelar_por_jerarquia
AFTER UPDATE ON ms1_nucleo.reserva
FOR EACH ROW EXECUTE FUNCTION ms1_nucleo.cancelar_por_jerarquia();

CREATE TABLE ms1_nucleo.historial_reserva (
    id              SERIAL PRIMARY KEY,
    reserva_id      INTEGER      NOT NULL REFERENCES ms1_nucleo.reserva(id) ON DELETE CASCADE,
    estado_anterior VARCHAR(25),
    estado_nuevo    VARCHAR(25)  NOT NULL,
    usuario_id      INTEGER               REFERENCES ms2_verificacion.usuario(id),
    comentario      VARCHAR(500),
    fecha           TIMESTAMP    NOT NULL DEFAULT now()
);

CREATE TABLE ms1_nucleo.horario_mantenimiento (
    id           SERIAL PRIMARY KEY,
    espacio_id   INTEGER      NOT NULL REFERENCES ms1_nucleo.espacio(id) ON DELETE CASCADE,
    fecha_inicio TIMESTAMP    NOT NULL,
    fecha_fin    TIMESTAMP    NOT NULL,
    motivo       VARCHAR(255),
    creado_por   INTEGER               REFERENCES ms2_verificacion.usuario(id)
);

-- tipo_dato indica cómo interpretar el valor: INTEGER, DECIMAL, BOOLEAN, STRING
-- rol_id y tipo_espacio_id permiten alcance opcional:
--   si ambos son NULL  → parámetro global (aplica a todos)
--   si rol_id tiene valor → aplica solo a ese rol (ej. máx. reservas para MODERADOR)
--   si tipo_espacio_id tiene valor → aplica solo a ese tipo de espacio
--   si ambos tienen valor → aplica a ese rol en ese tipo de espacio
-- El backend debe buscar primero el parámetro más específico y caer al global si no existe.
CREATE TABLE ms1_nucleo.parametro_sistema (
    id               SERIAL PRIMARY KEY,
    clave            VARCHAR(80)  NOT NULL,
    valor            VARCHAR(255) NOT NULL,
    tipo_dato        VARCHAR(10)  NOT NULL CHECK (tipo_dato IN ('INTEGER','DECIMAL','BOOLEAN','STRING')),
    descripcion      VARCHAR(255),
    activo           BOOLEAN      NOT NULL DEFAULT TRUE,
    rol_id           INTEGER               REFERENCES ms2_verificacion.rol(id) ON DELETE SET NULL,
    tipo_espacio_id  INTEGER               REFERENCES ms1_nucleo.tipo_espacio(id) ON DELETE SET NULL,
    modificado_por   INTEGER               REFERENCES ms2_verificacion.usuario(id),
    fecha_modif      TIMESTAMP,
    UNIQUE (clave, rol_id, tipo_espacio_id)  -- permite la misma clave con distintos alcances
);

CREATE TABLE ms1_nucleo.notificacion (
    id                  SERIAL PRIMARY KEY,
    usuario_id          INTEGER      NOT NULL REFERENCES ms2_verificacion.usuario(id) ON DELETE CASCADE,
    tipo                VARCHAR(40)  NOT NULL,
    mensaje             VARCHAR(500) NOT NULL,
    referencia_entidad  VARCHAR(60),   -- ej. 'reserva', 'convenio', 'mantenimiento'
    referencia_id       INTEGER,
    leida               BOOLEAN      NOT NULL DEFAULT FALSE,
    fecha               TIMESTAMP    NOT NULL DEFAULT now()
);

-- =====================================================================
-- ESQUEMA: ms3_inventario
-- Materiales y mantenimiento
-- =====================================================================

CREATE TABLE ms3_inventario.tipo_consumible (
    id            SERIAL PRIMARY KEY,
    nombre        VARCHAR(80) NOT NULL,
    umbral_alerta INTEGER     NOT NULL DEFAULT 0
);

CREATE TABLE ms3_inventario.inventario_espacio (
    id                 SERIAL PRIMARY KEY,
    espacio_id         INTEGER NOT NULL REFERENCES ms1_nucleo.espacio(id),
    tipo_consumible_id INTEGER NOT NULL REFERENCES ms3_inventario.tipo_consumible(id),
    saldo_disponible   INTEGER NOT NULL DEFAULT 0,
    UNIQUE (espacio_id, tipo_consumible_id)
);

CREATE TABLE ms3_inventario.movimiento_inventario (
    id                     SERIAL PRIMARY KEY,
    inventario_espacio_id  INTEGER      NOT NULL REFERENCES ms3_inventario.inventario_espacio(id),
    tipo_movimiento        VARCHAR(10)  NOT NULL CHECK (tipo_movimiento IN ('ENTRADA','SALIDA')),
    cantidad               INTEGER      NOT NULL CHECK (cantidad > 0),
    responsable_usuario_id INTEGER      NOT NULL REFERENCES ms2_verificacion.usuario(id),
    motivo                 VARCHAR(255),
    fecha                  TIMESTAMP    NOT NULL DEFAULT now()
);

-- =====================================================================
-- ESQUEMA: ms5_quejas
-- Sugerencias, reclamos y estadísticas
-- =====================================================================

CREATE TABLE ms5_quejas.sugerencia_reclamo (
    id              SERIAL PRIMARY KEY,
    usuario_id      INTEGER      NOT NULL REFERENCES ms2_verificacion.usuario(id),
    tipo            VARCHAR(20)  NOT NULL CHECK (tipo IN ('SUGERENCIA','MEJORA','RECLAMO')),
    contenido       TEXT         NOT NULL,
    estado          VARCHAR(20)  NOT NULL DEFAULT 'RECIBIDA',
    fecha           TIMESTAMP    NOT NULL DEFAULT now(),
    respuesta       TEXT,
    respondido_por  INTEGER               REFERENCES ms2_verificacion.usuario(id),
    fecha_respuesta TIMESTAMP
);

-- Métricas calculadas por el sistema (ej. tasa de aprobación, uso por espacio)
CREATE TABLE ms5_quejas.metrica_calculada (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(80)  NOT NULL,
    valor           NUMERIC      NOT NULL,
    unidad          VARCHAR(30),
    fecha_calculo   TIMESTAMP    NOT NULL DEFAULT now(),
    parametros      TEXT                           -- JSON con los filtros usados al calcular
);

-- Historial de reportes exportados
CREATE TABLE ms5_quejas.reporte_exportado (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(120) NOT NULL,
    formato         VARCHAR(10)  NOT NULL CHECK (formato IN ('PDF','CSV','XLSX')),
    generado_por    INTEGER               REFERENCES ms2_verificacion.usuario(id),
    fecha           TIMESTAMP    NOT NULL DEFAULT now(),
    ruta_archivo    VARCHAR(500)
);

-- NOTA: ms4_ia (Agente IA) no tiene esquema propio.
-- Consume datos anonimizados de ms1_nucleo y ms5_quejas vía API interna.
